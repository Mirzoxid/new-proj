<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=id3745688_control',
    'username' => 'id3745688_forcontrol',
    'password' => 'oygul92nokiac7',
    'charset' => 'utf8',
];
