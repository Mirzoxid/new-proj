<h1>Salom </h1>
<p>
	<?php foreach ($contents as $key) :?>
		<?php echo $key->short_story; ?><br />
	<?php endforeach; ?>
</p>